SPORTS CARD ANALYTICS PORTFOLIO

1) sports_card_market_intelligence.html
Interactive dashboard covering high-value sports cards, raw/graded market spreads, scarcity, liquidity, data methodology and market-price visualization.

2) sports_card_grading_roi_lab.html
Interactive raw-to-graded calculator with PSA 7–10 scenarios, break-even sale price, selling fees, expected profit and expected ROI.

Recommended public hosting:
- GitHub Pages: create a public repository, upload each project as index.html in its own repository, then enable Settings > Pages. GitHub publishes static HTML directly.
- Netlify: use the drag-and-drop deploy option for the project folder, or connect a GitHub repository.
